-- ----------------------------------
-- CREATING DATA BASE AND TABLES
-- ----------------------------------


SELECT * FROM `dbuser-uni`.tb_users;

CREATE TABLE `dbuser-uni`.`tb_users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  `pin` INT NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_spanish_ci;


-- ----------------------------------
-- CONSULTAS
-- ----------------------------------
select * from tb_users;
INSERT INTO tb_users VALUES (null,'admin', 'admin', '12345');















