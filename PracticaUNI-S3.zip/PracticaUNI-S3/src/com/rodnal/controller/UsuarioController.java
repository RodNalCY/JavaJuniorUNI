package com.rodnal.controller;

import com.rodnal.entity.Usuario;
import com.rodnal.modelo.UsuarioModelo;
import java.util.List;

public class UsuarioController {
    
    UsuarioModelo model;
    
    public UsuarioController(){
        model = new UsuarioModelo();
    }
    
    public void procesarNeoUsuario(Usuario u){
         model.neoUsuario(u);
    }
    
    public List<Usuario> procesarLista(){
        return model.listarUsuarios();
    }
    
}
