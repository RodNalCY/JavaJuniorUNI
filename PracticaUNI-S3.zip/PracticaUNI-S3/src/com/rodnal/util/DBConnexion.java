package com.rodnal.util;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class DBConnexion {
    
    private static String DRIVER   = "com.mysql.jdbc.Driver";
    private static String USUARIO  =  "dbrodnalcy";
    private static String PASSWORD = "12345";  
    private static String URL      = "jdbc:mysql://localhost:3306/dbuser-uni";
    
    static{
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN EL DRIVER: "+e);
        }
    }
    
    public Connection getConnection(){
       Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL,USUARIO,PASSWORD);
            System.out.println("Se conecto exitosamente a Mysql(dbuser-uni)....");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA CONEXION: "+e);
        }
        return connection;
    }
    
}
