package com.rodnal.modelo;

import com.rodnal.entity.Usuario;
import com.rodnal.util.DBConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class UsuarioModelo {

    DBConnexion dbconnexion;

    // EL executeUpdate devuelve 1 si se inserto c
    public int neoUsuario(Usuario u) {
        dbconnexion = new DBConnexion();
        int res;

        Connection con = dbconnexion.getConnection();
        String sql = "INSERT INTO tb_users VALUES (?,?,?,?);";
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, u.getId());
            pst.setString(2, u.getUser());
            pst.setString(3, u.getPassword());
            pst.setInt(4, u.getPin());
            res = pst.executeUpdate();
            pst.close();
            con.close();
            if (res == 1) {
                System.out.println("Se creo nuevo usuario: " + res);
            }
            return res;
        } catch (SQLException e) {
            System.err.println("ERROR AL INSERTAR REGISTRO");
            return 0;
        }

    }

    public List<Usuario> listarUsuarios() {
        
        dbconnexion = new DBConnexion();
        Connection con = dbconnexion.getConnection();

        String sql = "select * from tb_users";
        List<Usuario> lista = new ArrayList<>();
        
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            Usuario u;
            while (rs.next()) {
                u = new Usuario();
                u.setId(rs.getInt(1));
                u.setUser(rs.getString(2));
                u.setPassword(rs.getString(3));
                u.setPin(rs.getInt(4));
                lista.add(u);
            }
            rs.close();
            pst.close();
            con.close();
        } catch (SQLException e) {
            System.err.println("ERROR AL LISTAR: "+e);
        }
        return lista;
    }

}
